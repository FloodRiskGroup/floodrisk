=================================
Authors, Contributors and Funders
=================================

Authors ordered by date of first contribution:

* Leonardo Mancusi <leonardo.mancusi@rse-web.it>  - Ricerca sul Sistema Energetico S.p.A. - www.rse-web.it
* Raffaele Albano <raffaele.albano85@gmail.com>   - Università degli studi della Basilicata
* Aurelia Sole <aurelia.sole@unibas.it>           - Università degli studi della Basilicata - www.aureliasole.it

Other contributors who have have given contribution to research and development:
 
* Giorgia Faggiani <giorgia.faggiani@rse-web.it>       - Ricerca sul Sistema Energetico S.p.A. - www.rse-web.it
* Antonella Frigerio <antonella.frigerio@rse-web.it>   - Ricerca sul Sistema Energetico S.p.A. - www.rse-web.it
* Giansalvatore Mecca <giansalvatore.mecca@unibas.it>  - Università degli studi della Basilicata
* Davide Guglielmi <bourne_g89@hotmail.it>             

Other contributors who have provided input, documentations and translations.

* Leonardo Mancusi <leonardo.mancusi@rse-web.it>  - Ricerca sul Sistema Energetico S.p.A. - www.rse-web.it

Other contributors who have provided testing:

* Iulia Craciun <iulya_craciun@yahoo.com>              - Babes Bolyai University - www.ubbcluj.ro

This work was kindly supported by the Research Fund for the Italian Electrical System
under the Contract Agreement between RSE S.p.A. and the Ministry of Economic Development - General Directorate for Nuclear Energy, Renewable Energy and Energy Efficiency in compliance with the Decree of March 8, 2006
